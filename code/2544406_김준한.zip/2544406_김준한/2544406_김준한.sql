-- DB Final Project Skeleton
-- Student Name: 김준한
-- Student ID: 2544406

-- 1. CREATE TABLE

CREATE TABLE class_code (
    code INT PRIMARY KEY,
    class VARCHAR(20),
    basis VARCHAR(50)
);

CREATE TABLE task_code (
    code INT PRIMARY KEY,
    task VARCHAR(50)
);


CREATE TABLE customer (
    cus_id VARCHAR(15) PRIMARY KEY,             
    name   VARCHAR(20) NOT NULL,                
    cell   CHAR(13)    NOT NULL UNIQUE,         
    addr   VARCHAR(100),                        
    c_code INT DEFAULT 3                     
        REFERENCES class_code(code)
);

-- 직원
CREATE TABLE staff (
	staff_id INT PRIMARY KEY,
	name VARCHAR(30) NOT NULL,
	birthday INT NOT NULL,
	tel CHAR(12),
	salary INT,
	t_code INT NOT NULL REFERENCES task_code(code),
	hire_date CHAR(8) NOT NULL
);

-- 여행상품
CREATE TABLE tour (
	tour_num CHAR(8) PRIMARY KEY,
	departure VARCHAR(50) NOT NULL,
	arrival VARCHAR(50) NOT NULL,
	program VARCHAR(200),
	start_dt DATE NOT NULL,
	end_dt DATE NOT NULL,
	min_num INT,
	max_num INT,
	expense INT NOT NULL,
	deposit INT,
	dept_yn CHAR(1) DEFAULT 'N',
	staff_id INT REFERENCES staff(staff_id)
);

-- 예약하다
CREATE TABLE reserve (
	cus_id VARCHAR(15),
	tour_num CHAR(8),
	res_date CHAR(8) DEFAULT to_char(CURRENT_DATE, 'YYYYMMDD'),
	dep_yn CHAR(1) DEFAULT 'N',
	exp_yn CHAR(1) DEFAULT 'N',
	PRIMARY KEY (cus_id, tour_num),
	FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 운전 기사
CREATE TABLE driver (
	driver_id INT PRIMARY KEY,
	name VARCHAR(20) NOT NULL,
	birthday CHAR(6) NOT NULL,
	cell CHAR(13) NOT NULL,
	pay INT DEFAULT 15000,
	cont_date CHAR(8),
	cont_term CHAR(8)
);

-- 관광버스
CREATE TABLE tour_bus (
	bus_id INT PRIMARY KEY,
	seat INT,
	del_year INT
);

-- 운전 기사 할당
CREATE TABLE assign_driver (
	tour_num CHAR(8) PRIMARY KEY,
	driver_id INT REFERENCES driver(driver_id),
	work_hour INT,
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 차량 배정

CREATE TABLE assign_bus (
	tour_num CHAR(8) PRIMARY KEY,
	bus_id INT REFERENCES tour_bus(bus_id),
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- TODO: customer
-- TODO: staff
-- TODO: tour
-- TODO: reserve

CREATE TABLE customer (
    cus_id VARCHAR(15) PRIMARY KEY,             
    name   VARCHAR(20) NOT NULL,                
    cell   CHAR(13)    NOT NULL UNIQUE,         
    addr   VARCHAR(100),                        
    c_code INT DEFAULT 3                     
        REFERENCES class_code(code)
);

-- 직원
CREATE TABLE staff (
	staff_id INT PRIMARY KEY,
	name VARCHAR(30) NOT NULL,
	birthday INT NOT NULL,
	tel CHAR(12),
	salary INT,
	t_code INT NOT NULL REFERENCES task_code(code),
	hire_date CHAR(8) NOT NULL
);

-- 여행상품
CREATE TABLE tour (
	tour_num CHAR(8) PRIMARY KEY,
	departure VARCHAR(50) NOT NULL,
	arrival VARCHAR(50) NOT NULL,
	program VARCHAR(200),
	start_dt DATE NOT NULL,
	end_dt DATE NOT NULL,
	min_num INT,
	max_num INT,
	expense INT NOT NULL,
	deposit INT,
	dept_yn CHAR(1) DEFAULT 'N',
	staff_id INT REFERENCES staff(staff_id)
);

-- 예약하다
CREATE TABLE reserve (
	cus_id VARCHAR(15),
	tour_num CHAR(8),
	res_date CHAR(8) DEFAULT to_char(CURRENT_DATE, 'YYYYMMDD'),
	dep_yn CHAR(1) DEFAULT 'N',
	exp_yn CHAR(1) DEFAULT 'N',
	PRIMARY KEY (cus_id, tour_num),
	FOREIGN KEY (cus_id) REFERENCES customer(cus_id),
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 운전 기사
CREATE TABLE driver (
	driver_id INT PRIMARY KEY,
	name VARCHAR(20) NOT NULL,
	birthday CHAR(6) NOT NULL,
	cell CHAR(13) NOT NULL,
	pay INT DEFAULT 15000,
	cont_date CHAR(8),
	cont_term CHAR(8)
);

-- 관광버스
CREATE TABLE tour_bus (
	bus_id INT PRIMARY KEY,
	seat INT,
	del_year INT
);

-- 운전 기사 할당
CREATE TABLE assign_driver (
	tour_num CHAR(8) PRIMARY KEY,
	driver_id INT REFERENCES driver(driver_id),
	work_hour INT,
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 차량 배정

CREATE TABLE assign_bus (
	tour_num CHAR(8) PRIMARY KEY,
	bus_id INT REFERENCES tour_bus(bus_id),
	FOREIGN KEY (tour_num) REFERENCES tour(tour_num)
);

-- 2. INSERT DATA

-- TODO: Insert at least 5 rows into each table

INSERT INTO class_code (code, class, basis) VALUES
(1, '최우수', '연 4000만원 이상 구매'),
(2, '우수',   '연 1000만원 이상 구매'),
(3, '일반',   '기본 등급');

INSERT INTO task_code (code, task) VALUES
(1, '여행상품관리'),
(2, '예약관리'),
(3, '관광버스배차관리'),
(4, '직원관리'),
(5, '고객관리');

-- 고객
INSERT INTO customer (cus_id, name, cell, addr, c_code) VALUES
('hong123', '홍길동', '010-1111-2222', '서울시 강남구',   1),
('kim456',  '김철수', '010-2222-3333', '부산시 해운대구', 2),
('lee789',  '이영희', '010-3333-4444', '대구시 수성구',   3),
('park111', '박민수', '010-4444-5555', '인천시 연수구',   3),
('choi222', '최지은', '010-5555-6666', '광주시 서구',     2);

-- 직원
INSERT INTO staff (staff_id, name, birthday, tel, salary, t_code, hire_date) VALUES
(10001, '강대리', 900101, '02-1234-5678', 3500000, 1, '20180301'),
(10002, '윤과장', 850505, '02-2345-6789', 4500000, 2, '20150401'),
(10003, '서주임', 920202, '02-3456-7890', 3000000, 3, '20200302'),
(10004, '한부장', 800808, '02-4567-8901', 5500000, 4, '20100303'),
(10005, '오사원', 950303, '02-5678-9012', 2800000, 5, '20220304');

-- 여행상품
INSERT INTO tour
(tour_num, departure, arrival, program, start_dt, end_dt, min_num, max_num, expense, deposit, dept_yn, staff_id) VALUES
('T2026001', '서울', '제주', 'http://tour.co.kr/jeju',      '2026-07-01', '2026-07-03', 10, 30, 450000, 50000, 'N', 10001),
('T2026002', '서울', '부산', 'http://tour.co.kr/busan',     '2026-07-10', '2026-07-12', 15, 40, 380000, 40000, 'N', 10001),
('T2026003', '대전', '경주', 'http://tour.co.kr/gyeongju',  '2026-08-01', '2026-08-02',  8, 25, 250000, 30000, 'N', 10002),
('T2026004', '서울', '강릉', 'http://tour.co.kr/gangneung', '2026-08-15', '2026-08-16', 12, 35, 290000, 30000, 'Y', 10002),
('T2026005', '부산', '여수', 'http://tour.co.kr/yeosu',     '2026-09-01', '2026-09-03', 10, 30, 410000, 50000, 'N', 10001);

-- 운전기사
INSERT INTO driver (driver_id, name, birthday, cell, pay, cont_date, cont_term) VALUES
(20001, '정기사', '780101', '010-7777-1111', 18000, '20230101', '12'),
(20002, '강운전', '820202', '010-7777-2222', 16000, '20230201', '24'),
(20003, '문기사', '750303', '010-7777-3333', 20000, '20220301', '36'),
(20004, '신운전', '880404', '010-7777-4444', 15000, '20240101', '12'),
(20005, '조기사', '800505', '010-7777-5555', 17000, '20230601', '24');

-- 관광버스
INSERT INTO tour_bus (bus_id, seat, del_year) VALUES
(11, 45, 2020),
(12, 30, 2021),
(13, 25, 2022),
(14, 45, 2019),
(15, 40, 2023);

-- 예약
INSERT INTO reserve (cus_id, tour_num, res_date, dep_yn, exp_yn) VALUES
('hong123', 'T2026001', '20260601', 'Y', 'N'),
('kim456',  'T2026001', '20260602', 'Y', 'Y'),
('choi222', 'T2026001', '20260605', 'N', 'N'),
('lee789',  'T2026002', '20260603', 'N', 'N'),
('park111', 'T2026003', '20260604', 'Y', 'N');

-- 기사 배정
INSERT INTO assign_driver (tour_num, driver_id, work_hour) VALUES
('T2026001', 20001, 24),
('T2026002', 20002, 20),
('T2026003', 20003, 16),
('T2026004', 20001, 18),
('T2026005', 20004, 30);

-- 차량 배정
INSERT INTO assign_bus (tour_num, bus_id) VALUES
('T2026001', 11),
('T2026002', 12),
('T2026003', 13),
('T2026004', 14),
('T2026005', 15);

-- 3. INDEX

-- 도착지 오름차순
CREATE INDEX tour_arrival_idx ON tour (arrival ASC);

-- 운전 기사 오름차순
CREATE INDEX driver_name_idx ON driver (name ASC);

-- TODO: CREATE INDEX

-- 4. TEST QUERIES

-- Customer Grade Search
-- 고객 id로 이름 및 등급 검색
SELECT c.name, cc.class
FROM   customer c
JOIN   class_code cc ON c.c_code = cc.code
WHERE  c.cus_id = 'hong123';

-- Employee Task Search
-- 사번으로 이름 및 담당업무 검색
SELECT s.name, tc.task
FROM   staff s
JOIN   task_code tc ON s.t_code = tc.code
WHERE  s.staff_id = 10002;

-- Tour Reservation Search
-- 여행번호로 예약 고객의 이름, 예약일자, 예약금결제여부 검색
SELECT c.name, r.res_date, r.dep_yn
FROM   reserve r
JOIN   customer c ON r.cus_id = c.cus_id
WHERE  r.tour_num = 'T2026001';

-- Assigned Driver Search
-- 여행번호로 출발지, 배정기사 이름, 휴대폰 검색
SELECT t.departure, d.name, d.cell
FROM   tour t
JOIN   assign_driver ad ON t.tour_num  = ad.tour_num
JOIN   driver d         ON ad.driver_id = d.driver_id
WHERE  t.tour_num = 'T2026001';

-- INSERT example
-- 신규 고객 등록
INSERT INTO customer (cus_id, name, cell)
VALUES ('new001', '신규고객', '010-9999-0000');

-- UPDATE example
-- 직원 급여를 20만원 인상
UPDATE staff
SET    salary = salary + 200000
WHERE  staff_id = 10005;

-- DELETE example
-- 특정 고객 id + 여행 번호의 예약 정보 삭제
DELETE FROM reserve
WHERE  cus_id = 'lee789' AND tour_num = 'T2026002';